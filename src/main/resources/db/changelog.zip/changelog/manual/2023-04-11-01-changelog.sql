update j_one_piece_official_site_id set localization = 'us';
