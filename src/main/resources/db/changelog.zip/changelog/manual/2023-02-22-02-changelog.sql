ALTER TABLE `j_hbn_history__yugioh_card` add column `sneak_peek` tinyint(1) DEFAULT NULL;
