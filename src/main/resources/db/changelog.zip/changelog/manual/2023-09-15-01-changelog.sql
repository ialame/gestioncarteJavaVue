INSERT INTO j_field_mapping (`field`, `regex`, `source`, `value`) VALUES('sets.onp.us.code', 1, '(?i)^OP04$', 'OP-04');
