INSERT INTO j_field_mapping (`field`, `regex`, `source`, `value`) VALUES('cards.ygh.rarity', 1, '(?i)^Secret Rare$', 'ScR');
INSERT INTO j_field_mapping (`field`, `regex`, `source`, `value`) VALUES('cards.ygh.rarity', 1, '(?i)^Common$', 'C');
INSERT INTO j_field_mapping (`field`, `regex`, `source`, `value`) VALUES('cards.ygh.rarity', 1, '(?i)^Ultra Rare$', 'UR');
INSERT INTO j_field_mapping (`field`, `regex`, `source`, `value`) VALUES('cards.ygh.rarity', 1, '(?i)^Rare$', 'R');
